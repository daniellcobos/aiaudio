
class Config(object):
    DEBUG = True
    TESTING = False

class DevelopmentConfig(Config):
    SECRET_KEY = "7asdf3axcv247a29b6"
    GCK = 'xcv1-jm8jhhcivf64dufdrsi7el1252d8dphk.apps.googleusercontent.com'
    GCS = '_RTxcviz6mxcvcxvxcvxcvxcvxcvW7zZ0XOz'
    SQLALCHEMY_DATABASE_URI = "postgresql://postgres:cxxcvxcvcx34@12131231231232.248:5432/dbeasynet"
    OPENAI_API_KEY = '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'

config = {
    'development': DevelopmentConfig,
    'testing': DevelopmentConfig,
    'production': DevelopmentConfig
}

## Enter your Open API Key here
OPENAI_API_KEY = 'sk-IvuyRTdsfxcvxcvxcvxcDn0ixQYySktkUPkv'
PORT = 5000
DEBUG = True
APP_SECRET_KEY = "43df53bac7824657b9f908c26b09717314546456"
# Configuracion de bases de datos
POSTGRESQL_CONNECTION = "postgresql://postgres:3H21312z5Pgu0EBr@161231238:5432/dbeasynet"
SQLALCHEMY_TRACK_NOTIFICATIONS = False
