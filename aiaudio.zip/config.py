
class Config(object):
    DEBUG = True
    TESTING = False

class DevelopmentConfig(Config):
    SECRET_KEY = "78542d5ff3a48cb19c1f246e247a29b6"
    GCK = '165274845271-jm8jhhcivf64dufdrsi7el1252d8dphk.apps.googleusercontent.com'
    GCS = '_RTCbHXEXaAviz6mW7zZ0XOz'
    SQLALCHEMY_DATABASE_URI = "postgresql://postgres:@161.35.122.248:5432/dbeasynet"
    OPENAI_API_KEY = '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'

config = {
    'development': DevelopmentConfig,
    'testing': DevelopmentConfig,
    'production': DevelopmentConfig
}

## Enter your Open API Key here
OPENAI_API_KEY = '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'
PORT = 5000
DEBUG = True
APP_SECRET_KEY = "43df53bac7824657b9f908c26b09717314546456"
# Configuracion de bases de datos
POSTGRESQL_CONNECTION = "postgresql://postgres:HrwR0upe07RyFJ5Pgu0EBr@161.35.122.248:5432/dbeasynet"
SQLALCHEMY_TRACK_NOTIFICATIONS = False
