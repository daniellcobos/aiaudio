from flask_sqlalchemy import SQLAlchemy

sqla = SQLAlchemy()